/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    config: {
        mixins: {
            'Magento_Catalog/js/catalog-add-to-cart': {
                'RLTSquare_AjaxAddToCartPopup/js/catalog-add-to-cart-mixin': true
            }
        }
    }
};

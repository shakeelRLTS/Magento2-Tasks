<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'RLTSquare_AjaxAddToCartPopup',
    __DIR__
);
